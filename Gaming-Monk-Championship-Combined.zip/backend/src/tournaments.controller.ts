import { Controller, Get } from '@nestjs/common';

const demoTournaments = [
  { id: 'demo-solo', tournamentName: 'Gaming Monk Open Scrim — Solo', gameMode: 'SOLO', entryFeePaise: 0, currency: 'INR', totalSlots: 100, status: 'UPCOMING' },
  { id: 'demo-duo', tournamentName: 'Gaming Monk Open Scrim — Duo', gameMode: 'DUO', entryFeePaise: 0, currency: 'INR', totalSlots: 50, status: 'UPCOMING' },
  { id: 'demo-squad', tournamentName: 'Gaming Monk Open Scrim — Squad', gameMode: 'SQUAD', entryFeePaise: 0, currency: 'INR', totalSlots: 25, status: 'UPCOMING' }
];

@Controller('tournaments')
export class TournamentsController {
  @Get()
  listPublicTournaments() {
    // Phase 1 demo endpoint. Replace with Prisma-backed query before production.
    return { items: demoTournaments, total: demoTournaments.length };
  }
}
