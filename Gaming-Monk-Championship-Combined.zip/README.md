# Gaming Monk Championship — Combined Phase 1 + Phase 2

This repository combines the Phase 1 foundation with Phase 2 authentication and player-profile starter code.

## Included
- `backend/`: NestJS API, Prisma schema, OTP/JWT starter auth, player profiles, health endpoint
- `database/schema.sql`: Phase 1 PostgreSQL schema reference
- `website/`: Next.js starter website with login/profile UI
- `android/`: Flutter starter app with OTP/profile UI

## Important limitations
- This is a development starter, not a production-ready tournament platform. Tournament registration, teams, payments, admin tools, match rooms, scoring and leaderboards still need implementation and testing.
- OTP delivery is not production-ready. The development adapter logs OTPs locally; production requires an SMS provider integration. Never expose development OTPs publicly.
- Do not commit `.env` files or secrets. Configure environment variables in each hosting provider.
- Before public launch, configure HTTPS, CORS, rate limits, durable OTP storage, privacy/consent notices, backups and monitoring.

## Requirements
- Node.js 20+ and npm
- PostgreSQL 15+
- Flutter stable for Android builds

## Backend setup
1. Create a PostgreSQL database named `gaming_monk`.
2. In `backend/`, copy `.env.example` to `.env`. Set `DATABASE_URL` and a long random `JWT_ACCESS_SECRET`.
3. Run `npm install`.
4. Run `npx prisma generate`.
5. Run `npx prisma migrate dev --name phase2_auth_profiles` (development only).
6. Run `npm run start:dev`.

API base URL: `http://localhost:3001/api`
Health check: `GET /api/health`

## Website setup
1. In `website/`, run `npm install`.
2. Create `.env.local` with `NEXT_PUBLIC_API_URL=http://localhost:3001/api`.
3. Run `npm run dev` and open `http://localhost:3000`.

## Android setup
1. In `android/`, run `flutter pub get`.
2. Run `flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3001/api` for the Android emulator.
3. For a physical phone or release build, replace the API URL with your deployed HTTPS backend URL.

## Phase 2 API endpoints
- `POST /api/auth/request-otp` body: `{ "mobileNumber": "9876543210" }`
- `POST /api/auth/verify-otp` body: `{ "mobileNumber": "9876543210", "otp": "123456" }`
- `POST /api/players/profile` authenticated body: `{ "fullName": "...", "bgmiCharacterName": "...", "bgmiCharacterId": "..." }`
- `GET /api/players/me` authenticated

Use `Authorization: Bearer <accessToken>` for protected endpoints.
