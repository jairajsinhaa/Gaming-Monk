-- Gaming Monk Championship — PostgreSQL Phase 1 schema
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE user_role AS ENUM ('PLAYER', 'ADMIN', 'SUPER_ADMIN');
CREATE TYPE game_mode AS ENUM ('SOLO', 'DUO', 'SQUAD');
CREATE TYPE tournament_status AS ENUM ('DRAFT', 'UPCOMING', 'REGISTRATION_OPEN', 'REGISTRATION_CLOSED', 'LIVE', 'COMPLETED', 'CANCELLED');
CREATE TYPE payment_status AS ENUM ('PENDING', 'SUCCESS', 'FAILED', 'REFUND_PENDING', 'REFUNDED');
CREATE TYPE registration_status AS ENUM ('PENDING_PAYMENT', 'CONFIRMED', 'CANCELLED', 'REJECTED');
CREATE TYPE team_status AS ENUM ('OPEN', 'LOCKED', 'DISBANDED');
CREATE TYPE member_status AS ENUM ('PENDING', 'ACTIVE', 'REJECTED', 'LEFT');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name VARCHAR(120) NOT NULL,
  mobile_number VARCHAR(15) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE,
  password_hash TEXT,
  role user_role NOT NULL DEFAULT 'PLAYER',
  is_mobile_verified BOOLEAN NOT NULL DEFAULT FALSE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE player_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  bgmi_character_name VARCHAR(50) NOT NULL,
  bgmi_character_id VARCHAR(30) NOT NULL UNIQUE,
  avatar_url TEXT,
  verification_status VARCHAR(20) NOT NULL DEFAULT 'UNVERIFIED',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE teams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  team_name VARCHAR(60) NOT NULL,
  team_code VARCHAR(12) UNIQUE NOT NULL,
  captain_id UUID NOT NULL REFERENCES users(id),
  game_mode game_mode NOT NULL,
  max_members SMALLINT NOT NULL CHECK (
    (game_mode = 'SOLO' AND max_members = 1) OR
    (game_mode = 'DUO' AND max_members = 2) OR
    (game_mode = 'SQUAD' AND max_members = 4)
  ),
  status team_status NOT NULL DEFAULT 'OPEN',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE team_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  member_role VARCHAR(20) NOT NULL DEFAULT 'PLAYER',
  status member_status NOT NULL DEFAULT 'PENDING',
  joined_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(team_id, user_id)
);
CREATE INDEX idx_team_members_user_status ON team_members(user_id, status);

CREATE TABLE team_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  requester_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message VARCHAR(250),
  status member_status NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(team_id, requester_id)
);

CREATE TABLE tournaments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tournament_name VARCHAR(120) NOT NULL,
  description TEXT,
  game_mode game_mode NOT NULL,
  entry_fee_paise INTEGER NOT NULL DEFAULT 0 CHECK (entry_fee_paise >= 0),
  total_slots INTEGER NOT NULL CHECK (total_slots > 0),
  registration_deadline TIMESTAMPTZ,
  starts_at TIMESTAMPTZ,
  prize_description TEXT,
  rules_url TEXT,
  status tournament_status NOT NULL DEFAULT 'DRAFT',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE registrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  registration_number VARCHAR(24) UNIQUE NOT NULL,
  tournament_id UUID NOT NULL REFERENCES tournaments(id),
  team_id UUID REFERENCES teams(id),
  solo_player_id UUID REFERENCES users(id),
  status registration_status NOT NULL DEFAULT 'PENDING_PAYMENT',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK ((team_id IS NOT NULL AND solo_player_id IS NULL) OR
         (team_id IS NULL AND solo_player_id IS NOT NULL))
);
CREATE INDEX idx_registrations_tournament_status ON registrations(tournament_id, status);

CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  registration_id UUID NOT NULL REFERENCES registrations(id),
  gateway_name VARCHAR(40) NOT NULL,
  gateway_order_id VARCHAR(100) UNIQUE,
  gateway_payment_id VARCHAR(100) UNIQUE,
  amount_paise INTEGER NOT NULL CHECK (amount_paise >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  status payment_status NOT NULL DEFAULT 'PENDING',
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE matches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tournament_id UUID NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  match_name VARCHAR(100) NOT NULL,
  scheduled_at TIMESTAMPTZ,
  room_id VARCHAR(80),
  room_password_encrypted TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'SCHEDULED',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE match_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id UUID NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  registration_id UUID NOT NULL REFERENCES registrations(id),
  placement INTEGER CHECK (placement > 0),
  eliminations INTEGER NOT NULL DEFAULT 0 CHECK (eliminations >= 0),
  points NUMERIC(8,2) NOT NULL DEFAULT 0,
  verified_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(match_id, registration_id)
);

CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(120) NOT NULL,
  body TEXT NOT NULL,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id UUID REFERENCES users(id),
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(60) NOT NULL,
  entity_id UUID,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_tournaments_status_start ON tournaments(status, starts_at);
CREATE INDEX idx_payments_registration ON payments(registration_id);
CREATE INDEX idx_notifications_user_created ON notifications(user_id, created_at DESC);

-- Starter public tournament data (optional)
INSERT INTO tournaments
(tournament_name, description, game_mode, entry_fee_paise, total_slots, status)
VALUES
('Gaming Monk Open Scrim — Solo', 'Sample listing; replace with your actual event rules.', 'SOLO', 0, 100, 'UPCOMING'),
('Gaming Monk Open Scrim — Duo', 'Sample listing; replace with your actual event rules.', 'DUO', 0, 50, 'UPCOMING'),
('Gaming Monk Open Scrim — Squad', 'Sample listing; replace with your actual event rules.', 'SQUAD', 0, 25, 'UPCOMING');
