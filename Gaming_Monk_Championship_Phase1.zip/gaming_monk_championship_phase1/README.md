# Gaming Monk Championship — Phase 1

Starter monorepo for:
- `backend/`: NestJS + Prisma + PostgreSQL API foundation
- `database/`: PostgreSQL schema and seed SQL
- `website/`: Next.js public website starter
- `android/`: Flutter Android starter
- `.env.example`: local configuration template

## Requirements
- Node.js 20+
- PostgreSQL 15+
- Flutter stable (for Android app)
- npm

## 1. Database
Create a PostgreSQL database:
```sql
CREATE DATABASE gaming_monk;
```
Apply the SQL:
```bash
psql -d gaming_monk -f database/schema.sql
```

## 2. Backend
```bash
cd backend
cp ../.env.example .env
npm install
npx prisma generate
npm run start:dev
```
API base URL: `http://localhost:3001/api`

Health check: `GET /api/health`

## 3. Website
```bash
cd website
npm install
npm run dev
```
Open `http://localhost:3000`.

Set `NEXT_PUBLIC_API_URL=http://localhost:3001/api` in `website/.env.local` if using the API.

## 4. Android
```bash
cd android
flutter pub get
flutter run
```
For Android emulator, the API host is `10.0.2.2`, not `localhost`.
Update `apiBaseUrl` in `android/lib/main.dart` for your deployment.

## Phase 1 scope
This is a development starter, not a production-ready tournament/payment system.
Included: health endpoint, public tournament listing endpoint, database foundation, public website landing page, Flutter starter UI.
Next phases: verified mobile OTP, player profile, team create/join workflows, tournament registration, payment gateway webhooks, admin roles, match rooms, scoring and leaderboard.

## Security notes
- Never commit `.env` or secrets.
- Passwords must be hashed (Argon2id/bcrypt) when password login is implemented.
- Payment success must be verified server-to-server using signed gateway webhooks.
- Do not store card/UPI PIN data.
- Add rate limiting, validation, audit logs, backups and HTTPS before production.
- Use BGMI/KRAFTON branding only with applicable permissions; otherwise present this as an independent community tournament platform.
