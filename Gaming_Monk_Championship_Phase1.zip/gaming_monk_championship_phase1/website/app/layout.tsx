import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = {
  title: 'Gaming Monk Championship',
  description: 'Independent community esports tournament platform.'
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
