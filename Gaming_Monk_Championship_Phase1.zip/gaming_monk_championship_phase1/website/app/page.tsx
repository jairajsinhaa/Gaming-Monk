const modes = [
  { name: 'SOLO', players: '1 Player', detail: 'Individual registration' },
  { name: 'DUO', players: '2 Players', detail: 'Captain + teammate' },
  { name: 'SQUAD', players: '4 Players', detail: 'Full team registration' }
];
export default function Home() {
  return <main className="shell">
    <nav className="nav"><div className="brand">GAMING MONK</div><span className="pill">CHAMPIONSHIP</span></nav>
    <section className="hero">
      <div className="eyebrow">COMMUNITY ESPORTS PLATFORM</div>
      <h1>PLAY BOLD.<br/><span style={{color:'#ff515c'}}>RISE TO THE TOP.</span></h1>
      <p className="muted">Gaming Monk Championship brings players together for organized Solo, Duo and Squad tournaments. Create a team, join your friends and follow tournament updates in one place.</p>
      <div className="actions"><a className="btn" href="#modes">Explore Modes</a><a className="btn secondary" href="#about">How it works</a></div>
    </section>
    <h2 className="sectionTitle" id="modes">Tournament modes</h2>
    <section className="cards">{modes.map(m => <article className="card" key={m.name}><span className="tag">TOURNAMENT</span><h3>{m.name}</h3><p className="muted">{m.players} · {m.detail}</p></article>)}</section>
    <h2 className="sectionTitle" id="about">Your tournament hub</h2>
    <section className="cards">
      <article className="card"><h3>Create or join teams</h3><p className="muted">Build a roster or request to join an open team.</p></article>
      <article className="card"><h3>Public registration</h3><p className="muted">Browse public event information and registration announcements.</p></article>
      <article className="card"><h3>Match updates</h3><p className="muted">Follow schedules, verified results and leaderboard updates.</p></article>
    </section>
    <footer>Gaming Monk Championship · Currency: INR (₹)<br/>Independent community tournament platform. Not affiliated with or endorsed by KRAFTON or BGMI.</footer>
  </main>;
}
