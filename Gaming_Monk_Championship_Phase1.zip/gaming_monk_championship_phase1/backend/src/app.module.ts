import { Module } from '@nestjs/common';
import { HealthController } from './health.controller';
import { TournamentsController } from './tournaments.controller';

@Module({ controllers: [HealthController, TournamentsController] })
export class AppModule {}
