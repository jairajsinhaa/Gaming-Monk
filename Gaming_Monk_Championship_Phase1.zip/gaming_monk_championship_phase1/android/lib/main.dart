import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://10.0.2.2:3001/api',
);

void main() => runApp(const GamingMonkApp());

class GamingMonkApp extends StatelessWidget {
  const GamingMonkApp({super.key});
  @override
  Widget build(BuildContext context) {
    const red = Color(0xFFE83B48);
    return MaterialApp(
      title: 'Gaming Monk Championship',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090B10),
        colorScheme: ColorScheme.fromSeed(seedColor: red, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<dynamic> tournaments = [];
  bool loading = false;
  String? error;

  Future<void> loadTournaments() async {
    setState(() { loading = true; error = null; });
    try {
      final response = await http.get(Uri.parse('$apiBaseUrl/tournaments'));
      if (response.statusCode != 200) throw Exception('API returned ${response.statusCode}');
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      setState(() => tournaments = data['items'] as List<dynamic>);
    } catch (e) {
      setState(() => error = 'Could not connect to API. Check backend URL and server.');
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  void initState() { super.initState(); loadTournaments(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('GAMING MONK'), actions: [
        IconButton(onPressed: loadTournaments, icon: const Icon(Icons.refresh))
      ]),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [Color(0xFF54212A), Color(0xFF171B27)]),
            border: Border.all(color: const Color(0xFF51323A)),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('CHAMPIONSHIP', style: TextStyle(color: Color(0xFFFF747D), letterSpacing: 2, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text('PLAY BOLD.\\nRISE TO THE TOP.', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
            SizedBox(height: 8),
            Text('Community tournaments · Solo · Duo · Squad'),
          ]),
        ),
        const SizedBox(height: 24),
        const Text('UPCOMING TOURNAMENTS', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        if (loading) const Center(child: CircularProgressIndicator()),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.orangeAccent)),
        ...tournaments.map((item) => Card(
          color: const Color(0xFF171C27),
          child: ListTile(
            leading: const Icon(Icons.emoji_events, color: Color(0xFFFF626B)),
            title: Text(item['tournamentName']?.toString() ?? 'Tournament'),
            subtitle: Text('${item['gameMode']} · INR ₹'),
            trailing: const Icon(Icons.chevron_right),
          ),
        )),
        if (!loading && tournaments.isEmpty && error == null)
          const Text('No public tournaments available yet.'),
        const SizedBox(height: 18),
        const Text('Phase 1 starter: player login, team workflows and payment checkout will be added in later phases.',
          style: TextStyle(color: Colors.white60, height: 1.5)),
      ]),
    );
  }
}
