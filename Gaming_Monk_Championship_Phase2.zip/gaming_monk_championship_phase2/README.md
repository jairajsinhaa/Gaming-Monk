# Gaming Monk Championship — Phase 2

Phase 2 adds:
- Mobile OTP request and verification API
- JWT access token issuance
- Player profile creation and retrieval
- Prisma models for users, OTP challenges and player profiles
- Flutter OTP + player profile starter screens
- Next.js login/profile starter page

## Important OTP limitation
The included OTP service is a development adapter. In development it logs the OTP to the backend console. In production it deliberately refuses to send OTP until an SMS provider adapter is configured. Do not expose development OTPs to public users.

## Requirements
Node.js 20+, PostgreSQL 15+, Flutter stable.

## Setup
1. Create DB:
   `createdb gaming_monk`
2. In `backend`, copy `.env.example` to `.env`, set a long random `JWT_ACCESS_SECRET` and `DATABASE_URL`.
3. Install and migrate:
   ```bash
   npm install
   npx prisma generate
   npx prisma migrate dev --name phase2_auth_profiles
   npm run start:dev
   ```
4. Website:
   ```bash
   cd ../website
   npm install
   npm run dev
   ```
   Configure `NEXT_PUBLIC_API_URL=http://localhost:3001/api` in `.env.local`.
5. Android:
   ```bash
   cd ../android
   flutter pub get
   flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3001/api
   ```

## API endpoints
- `POST /api/auth/request-otp` body: `{ "mobileNumber": "9876543210" }`
- `POST /api/auth/verify-otp` body: `{ "mobileNumber": "9876543210", "otp": "123456" }`
- `POST /api/players/profile` authenticated body: `{ "fullName": "...", "bgmiCharacterName": "...", "bgmiCharacterId": "..." }`
- `GET /api/players/me` authenticated

Use `Authorization: Bearer <accessToken>` for protected endpoints.

## Production checklist
- Implement and verify an SMS provider (OTP delivery + delivery status).
- Use Redis or a durable OTP store with rate limits and expiry.
- Enable HTTPS, strict CORS, request throttling and monitoring.
- Add consent/privacy notice and retention policy.
- Add admin-controlled account support and audit logging.
- Do not add payment collection until applicable age, guardian-consent, event and payment-provider requirements have been reviewed.
