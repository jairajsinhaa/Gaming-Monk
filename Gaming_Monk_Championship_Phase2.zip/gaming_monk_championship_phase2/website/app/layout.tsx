import './globals.css';
export const metadata = { title: 'Gaming Monk Championship', description: 'Player sign-in and profile setup' };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
