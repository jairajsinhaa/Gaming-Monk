'use client';
import { useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api';
export default function Home() {
  const [mobile,setMobile] = useState('');
  const [otp,setOtp] = useState('');
  const [token,setToken] = useState('');
  const [fullName,setFullName] = useState('');
  const [ign,setIgn] = useState('');
  const [bgmiId,setBgmiId] = useState('');
  const [message,setMessage] = useState('');
  async function requestOtp() {
    setMessage('Requesting OTP...');
    try { const r=await fetch(`${API}/auth/request-otp`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mobileNumber:mobile})});
      const d=await r.json(); if(!r.ok) throw new Error(d.message||'OTP request failed'); setMessage('OTP request created. In local development, check backend terminal for the test OTP.');
    } catch(e:any){setMessage(e.message);}
  }
  async function verifyOtp() {
    setMessage('Verifying...');
    try { const r=await fetch(`${API}/auth/verify-otp`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mobileNumber:mobile,otp})});
      const d=await r.json(); if(!r.ok) throw new Error(d.message||'Verification failed'); setToken(d.accessToken); setMessage('Mobile verified. Complete your player profile below.');
    } catch(e:any){setMessage(e.message);}
  }
  async function saveProfile() {
    try { const r=await fetch(`${API}/players/profile`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({fullName,bgmiCharacterName:ign,bgmiCharacterId:bgmiId})});
      const d=await r.json(); if(!r.ok) throw new Error(d.message||'Profile save failed'); setMessage('Player profile created successfully.');
    } catch(e:any){setMessage(e.message);}
  }
  return <main className="wrap"><div className="panel">
    <div className="brand">GAMING MONK CHAMPIONSHIP</div><h1>Player registration</h1>
    <p className="muted">Sign in with your mobile number, verify it, then create your BGMI player profile.</p>
    <label>Indian mobile number</label><input value={mobile} onChange={e=>setMobile(e.target.value)} placeholder="10-digit mobile number" maxLength={10}/>
    <button onClick={requestOtp} disabled={!/^[6-9]\d{9}$/.test(mobile)}>Request OTP</button>
    <label>6-digit OTP</label><input value={otp} onChange={e=>setOtp(e.target.value)} placeholder="Enter OTP" maxLength={6}/>
    <button onClick={verifyOtp} disabled={!/^\d{6}$/.test(otp)}>Verify OTP</button>
    {token && <><hr/><h2>Player profile</h2>
      <label>Full name</label><input value={fullName} onChange={e=>setFullName(e.target.value)} placeholder="Your name"/>
      <label>BGMI character name</label><input value={ign} onChange={e=>setIgn(e.target.value)} placeholder="In-game name"/>
      <label>BGMI Character ID</label><input value={bgmiId} onChange={e=>setBgmiId(e.target.value)} placeholder="Numeric character ID"/>
      <button onClick={saveProfile} disabled={!fullName.trim()||!ign.trim()||! /^\d{5,30}$/.test(bgmiId)}>Save player profile</button>
    </>}
    <p className="notice">{message}</p>
    <p className="muted">Development note: OTP delivery is not connected to an SMS provider yet. Never use development OTP logging in a public production deployment.</p>
  </div></main>;
}
