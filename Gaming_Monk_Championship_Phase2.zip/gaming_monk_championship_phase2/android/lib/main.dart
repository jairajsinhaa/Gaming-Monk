import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:3001/api');
void main() => runApp(const GamingMonkApp());

class GamingMonkApp extends StatelessWidget {
  const GamingMonkApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'Gaming Monk Championship', debugShowCheckedModeBanner: false,
    theme: ThemeData(brightness: Brightness.dark, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFE83B48), brightness: Brightness.dark), scaffoldBackgroundColor: const Color(0xFF090B10)),
    home: const AuthScreen(),
  );
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override State<AuthScreen> createState() => _AuthScreenState();
}
class _AuthScreenState extends State<AuthScreen> {
  final mobile = TextEditingController(), otp = TextEditingController();
  final name = TextEditingController(), ign = TextEditingController(), bgmiId = TextEditingController();
  String? token; String message = ''; bool busy = false;
  Future<void> call(String path, Map<String,dynamic> body, {String? bearer, required void Function(Map<String,dynamic>) onSuccess}) async {
    setState(() { busy = true; message = ''; });
    try {
      final response = await http.post(Uri.parse('$apiBaseUrl$path'), headers: {
        'Content-Type':'application/json', if (bearer != null) 'Authorization':'Bearer $bearer'
      }, body: jsonEncode(body));
      final data = jsonDecode(response.body) as Map<String,dynamic>;
      if (response.statusCode < 200 || response.statusCode >= 300) throw Exception(data['message']?.toString() ?? 'Request failed');
      onSuccess(data);
    } catch (e) { setState(() => message = e.toString().replaceFirst('Exception: ','')); }
    finally { if (mounted) setState(() => busy = false); }
  }
  InputDecoration decoration(String label) => InputDecoration(labelText: label, border: const OutlineInputBorder());
  Widget field(TextEditingController c, String label, {TextInputType type = TextInputType.text, int? max}) =>
    Padding(padding: const EdgeInsets.only(bottom: 12), child: TextField(controller:c, keyboardType:type, maxLength:max, decoration:decoration(label)));
  @override void dispose(){mobile.dispose();otp.dispose();name.dispose();ign.dispose();bgmiId.dispose();super.dispose();}
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('GAMING MONK CHAMPIONSHIP')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('PLAYER REGISTRATION', style: TextStyle(fontSize:22,fontWeight:FontWeight.w900,color:Color(0xFFFF6872))),
      const SizedBox(height:8), const Text('Verify your mobile number and set up your player profile.'),
      const SizedBox(height:22), field(mobile,'10-digit mobile number',type:TextInputType.phone,max:10),
      FilledButton(onPressed: busy ? null : () => call('/auth/request-otp', {'mobileNumber':mobile.text}, onSuccess: (_) => setState(()=>message='OTP requested. Check backend terminal in development mode.')), child: const Text('REQUEST OTP')),
      const SizedBox(height:16), field(otp,'6-digit OTP',type:TextInputType.number,max:6),
      FilledButton(onPressed: busy ? null : () => call('/auth/verify-otp', {'mobileNumber':mobile.text,'otp':otp.text}, onSuccess:(d)=>setState(()=>token=d['accessToken'] as String)), child: const Text('VERIFY OTP')),
      if (token != null) ...[
        const Divider(height:32), const Text('PLAYER PROFILE',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        field(name,'Full name'), field(ign,'BGMI character name'), field(bgmiId,'Numeric BGMI Character ID',type:TextInputType.number),
        FilledButton(onPressed: busy ? null : () => call('/players/profile', {'fullName':name.text,'bgmiCharacterName':ign.text,'bgmiCharacterId':bgmiId.text}, bearer:token, onSuccess:(_) => setState(()=>message='Player profile saved successfully.')), child: const Text('SAVE PLAYER PROFILE')),
      ],
      if (busy) const Padding(padding:EdgeInsets.all(12),child:Center(child:CircularProgressIndicator())),
      if (message.isNotEmpty) Padding(padding:const EdgeInsets.only(top:16),child:Text(message,style:const TextStyle(color:Color(0xFFFFD27A)))),
      const SizedBox(height:16), const Text('OTP SMS delivery provider must be configured before public production use.',style:TextStyle(color:Colors.white60)),
    ]));
}
