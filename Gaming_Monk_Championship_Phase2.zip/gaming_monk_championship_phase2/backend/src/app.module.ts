import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PrismaService } from './prisma.service';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { PlayersController } from './players.controller';
import { PlayersService } from './players.service';
import { JwtAuthGuard } from './jwt-auth.guard';
import { HealthController } from './health.controller';

@Module({
  imports: [JwtModule.register({ secret: process.env.JWT_ACCESS_SECRET, signOptions: { expiresIn: process.env.JWT_ACCESS_TTL ?? '15m' } })],
  controllers: [HealthController, AuthController, PlayersController],
  providers: [PrismaService, AuthService, PlayersService, JwtAuthGuard],
})
export class AppModule {}
