import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { CreatePlayerProfileDto } from './players.dto';
@Injectable()
export class PlayersService {
  constructor(private readonly prisma: PrismaService) {}
  async createProfile(userId: string, dto: CreatePlayerProfileDto) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundException('Player account not found.');
    try {
      const profile = await this.prisma.playerProfile.create({
        data: { userId, bgmiCharacterName: dto.bgmiCharacterName.trim(),
          bgmiCharacterId: dto.bgmiCharacterId.trim(), avatarUrl: dto.avatarUrl },
      });
      await this.prisma.user.update({ where: { id: userId }, data: { fullName: dto.fullName.trim() } });
      return { message: 'Player profile created.', profile };
    } catch (error: any) {
      if (error?.code === 'P2002') throw new ConflictException('This BGMI Character ID is already registered.');
      throw error;
    }
  }
  async getMe(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId }, include: { profile: true },
    });
    if (!user) throw new NotFoundException('Player account not found.');
    const { profile, ...safeUser } = user;
    return { user: safeUser, profile };
  }
}
