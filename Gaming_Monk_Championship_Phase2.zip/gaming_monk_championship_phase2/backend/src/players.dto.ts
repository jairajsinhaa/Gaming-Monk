import { IsOptional, IsString, Length, Matches } from 'class-validator';
export class CreatePlayerProfileDto {
  @IsString() @Length(2, 120)
  fullName!: string;
  @IsString() @Length(2, 50)
  bgmiCharacterName!: string;
  @IsString() @Matches(/^\d{5,30}$/)
  bgmiCharacterId!: string;
  @IsOptional() @IsString()
  avatarUrl?: string;
}
