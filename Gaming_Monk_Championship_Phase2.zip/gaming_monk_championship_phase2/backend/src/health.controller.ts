import { Controller, Get } from '@nestjs/common';
@Controller('health')
export class HealthController {
  @Get()
  getHealth() { return { app: 'Gaming Monk Championship API', status: 'ok', phase: 2, timestamp: new Date().toISOString() }; }
}
