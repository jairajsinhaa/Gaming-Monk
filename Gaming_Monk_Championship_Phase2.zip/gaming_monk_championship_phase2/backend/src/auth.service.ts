import { BadRequestException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { createHash, randomInt } from 'crypto';
import { PrismaService } from './prisma.service';

@Injectable()
export class AuthService {
  constructor(private readonly prisma: PrismaService, private readonly jwt: JwtService) {}

  private hashOtp(otp: string) {
    return createHash('sha256').update(`${otp}:${process.env.JWT_ACCESS_SECRET}`).digest('hex');
  }

  async requestOtp(mobileNumber: string) {
    const recent = await this.prisma.otpChallenge.count({
      where: { mobileNumber, createdAt: { gte: new Date(Date.now() - 60_000) } }
    });
    if (recent >= 1) throw new BadRequestException('Please wait before requesting another OTP.');

    const otp = String(randomInt(100000, 1_000_000));
    const ttl = Number(process.env.OTP_TTL_SECONDS ?? 300);
    await this.prisma.otpChallenge.create({
      data: { mobileNumber, otpHash: this.hashOtp(otp), expiresAt: new Date(Date.now() + ttl * 1000) }
    });

    // Development-only delivery. Production must use a verified SMS provider.
    if (process.env.NODE_ENV !== 'production' && process.env.OTP_DEV_LOG === 'true') {
      console.info(`[DEV ONLY] Gaming Monk OTP for ${mobileNumber}: ${otp}`);
    } else if (process.env.NODE_ENV === 'production') {
      throw new Error('SMS provider is not configured. OTP delivery is disabled in production.');
    }
    return { message: 'If this number can receive messages, an OTP request has been created.', expiresInSeconds: ttl };
  }

  async verifyOtp(mobileNumber: string, otp: string) {
    const challenge = await this.prisma.otpChallenge.findFirst({
      where: { mobileNumber, consumedAt: null, expiresAt: { gt: new Date() }, attempts: { lt: 5 } },
      orderBy: { createdAt: 'desc' }
    });
    if (!challenge || challenge.otpHash !== this.hashOtp(otp)) {
      if (challenge) await this.prisma.otpChallenge.update({ where: { id: challenge.id }, data: { attempts: { increment: 1 } } });
      throw new UnauthorizedException('Invalid or expired OTP.');
    }

    await this.prisma.otpChallenge.update({ where: { id: challenge.id }, data: { consumedAt: new Date() } });
    const user = await this.prisma.user.upsert({
      where: { mobileNumber },
      update: { isMobileVerified: true },
      create: { mobileNumber, fullName: 'New Player', isMobileVerified: true }
    });
    if (!user.isActive) throw new UnauthorizedException('This account is disabled.');
    const accessToken = await this.jwt.signAsync({ sub: user.id, role: user.role, mobileNumber: user.mobileNumber });
    return { accessToken, tokenType: 'Bearer', expiresIn: process.env.JWT_ACCESS_TTL ?? '15m',
      user: { id: user.id, fullName: user.fullName, mobileNumber: user.mobileNumber, isMobileVerified: user.isMobileVerified, profileComplete: false } };
  }
}
