import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from './jwt-auth.guard';
import { PlayersService } from './players.service';
import { CreatePlayerProfileDto } from './players.dto';
@Controller('players')
@UseGuards(JwtAuthGuard)
export class PlayersController {
  constructor(private readonly players: PlayersService) {}
  @Post('profile')
  createProfile(@Req() req: any, @Body() dto: CreatePlayerProfileDto) {
    return this.players.createProfile(req.user.sub, dto);
  }
  @Get('me')
  getMe(@Req() req: any) { return this.players.getMe(req.user.sub); }
}
